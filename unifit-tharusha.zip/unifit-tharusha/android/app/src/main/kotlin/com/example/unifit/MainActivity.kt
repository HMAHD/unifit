package com.example.unifit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
